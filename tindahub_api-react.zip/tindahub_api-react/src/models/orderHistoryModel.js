const mongoose = require("mongoose");

const OrderHistorySchema = new mongoose.Schema({
    history_id: { type: mongoose.Schema.Types.ObjectId, auto: true }, 
    order_id: { type: mongoose.Schema.Types.ObjectId, ref: "Order", required: true }, 
    status: { 
        type: String, 
        enum: ["placed", "confirmed", "preparing", "ready_for_pickup", "completed", "canceled"], 
        required: true 
    }, 
    status_timestamp: { type: Date, default: Date.now } 
});

module.exports = mongoose.model("OrderHistory", OrderHistorySchema);