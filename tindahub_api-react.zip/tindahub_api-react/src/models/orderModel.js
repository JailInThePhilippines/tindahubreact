const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    vendor_id: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor", required: true },
    total_amount: Number,
    pickup_time: Date,
    order_status: {
        type: String,
        enum: ["placed", "confirmed", "preparing", "ready_for_pickup", "completed", "canceled"],
        default: "placed"
    },
    request_status: { type: String, enum: ["pending", "accepted", "rejected"], default: "pending" },
    order_date: { type: Date, default: Date.now },
    special_instruction: String,
    mode_of_payment: String,
    isPaid: { type: Boolean, default: false },
    payment_id: String
});

module.exports = mongoose.model("Order", OrderSchema);