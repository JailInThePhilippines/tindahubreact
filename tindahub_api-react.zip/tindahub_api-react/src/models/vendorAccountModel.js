// vendorAccountModel.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const vendorAccountSchema = new mongoose.Schema({
    vendor_name: { type: String, required: true },
    vendor_email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    password: {
        type: String,
        required: function () {
            return !this.googleId;
        }
    },
    contact_number: {
        type: String,
        required: function () {
            return !this.googleId;
        }
    },
    date_registered: { type: Date, default: Date.now },
    googleId: { type: String },
    resetPasswordToken: String,
    resetPasswordExpires: Date
}, {
    timestamps: true
});

// Pre-save middleware to hash password
vendorAccountSchema.pre('save', async function (next) {
    if (this.isModified('password') && this.password) {
        try {
            const salt = await bcrypt.genSalt(10);
            this.password = await bcrypt.hash(this.password, salt);
        } catch (error) {
            return next(error);
        }
    }
    next();
});

// Add this to hash password when resetting
vendorAccountSchema.pre('findOneAndUpdate', async function (next) {
    if (this._update.password) {
        try {
            const salt = await bcrypt.genSalt(10);
            this._update.password = await bcrypt.hash(this._update.password, salt);
        } catch (error) {
            return next(error);
        }
    }
    next();
});

module.exports = mongoose.model('VendorAccount', vendorAccountSchema);