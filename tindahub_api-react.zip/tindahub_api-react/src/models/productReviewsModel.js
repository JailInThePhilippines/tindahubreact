const mongoose = require("mongoose");

const ProductReviewSchema = new mongoose.Schema({
    product_id: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    review_date: { type: Date, default: Date.now },
    rating: { type: Number, required: true },
    comment: String,
    vendor_id: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor", required: true }
  });
  
  module.exports = mongoose.model("ProductReview", ProductReviewSchema);