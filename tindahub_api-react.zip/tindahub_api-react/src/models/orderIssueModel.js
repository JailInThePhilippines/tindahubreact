const mongoose = require("mongoose");

const OrderIssueReportSchema = new mongoose.Schema({
    order_id: { type: mongoose.Schema.Types.ObjectId, ref: "Order", required: true },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    issue_type: { type: String, required: true },
    additional_details: String,
    report_date: { type: Date, default: Date.now },
    status: { type: String, enum: ["pending", "resolved", "in_progress"], default: "pending" },
    resolved_date: Date
  });
  
  module.exports = mongoose.model("OrderIssueReport", OrderIssueReportSchema);