const mongoose = require('mongoose');

const vendorSchema = new mongoose.Schema({
  vendor_id: { type: mongoose.Schema.Types.ObjectId, ref: "VendorAccount", required: true },
  vendor_name: { type: String, required: true },
  email: {
    type: String,
    required: true,
    unique: true,
    sparse: true
  },
  location: {
    type: String,
    required: function () {
      return !this.googleId;
    }
  },
  rating: { type: Number, default: 0 },
  description: {
    type: String,
    required: function () {
      return !this.googleId;
    }
  },
  operating_hours: String,
  business_permit: String,
  vendor_profile_image: String,
  emailVerified: { type: Boolean, default: false },
  emailVerificationToken: String,
  emailVerificationTokenExpires: Date,
}, {
  timestamps: true
});

// Pre-save middleware to ensure email is synchronized
vendorSchema.pre('save', async function (next) {
  if (this.isNew || this.isModified('vendor_id')) {
    try {
      const vendorAccount = await mongoose.model('VendorAccount').findById(this.vendor_id);
      if (vendorAccount) {
        this.email = vendorAccount.vendor_email;
      }
    } catch (error) {
      next(error);
    }
  }
  next();
});

module.exports = mongoose.model('Vendor', vendorSchema);