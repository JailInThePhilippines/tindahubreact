const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
    vendor_id: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor", required: true },
    category: { type: String, required: true },
    product_name: { type: String, required: true },
    description: String,
    price: { type: Number, required: true },
    availability: { type: Boolean, default: true },
    prod_img: String,
    date: { type: Date, default: Date.now },
    quantity: Number,
    track_quantity: { type: Boolean, default: false }
});

module.exports = mongoose.model("Product", ProductSchema);