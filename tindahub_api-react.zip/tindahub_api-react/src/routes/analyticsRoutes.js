const express = require('express');
const router = express.Router();
const { getMonthlySales, getWeeklySales, getMostOrderedProducts, getMostOrderedProduct, getAllSalesReports, getTotalOrdersAndRevenue } = require('../controllers/analyticsController')
const authMiddleware = require('../middleware/authMiddleware');

router.get('/monthlysales', authMiddleware, getMonthlySales);

router.get('/weeklysales', authMiddleware, getWeeklySales);

router.get('/mostorderedproducts', authMiddleware, getMostOrderedProducts);

router.get('/mostorderedproduct', authMiddleware, getMostOrderedProduct);

router.get('/salesreport', authMiddleware, getAllSalesReports);

router.get('/totalordersandrevenue', authMiddleware, getTotalOrdersAndRevenue);

module.exports = router;