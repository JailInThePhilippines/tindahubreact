const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const { createProduct, getVendorProducts, searchProducts, getProductCount, updateProduct, getProductById, deleteProduct, deleteMultipleProducts } = require('../controllers/productController');
const { upload } = require('../config/cloudinaryConfig');
const authMiddleware = require('../middleware/authMiddleware');

router.post(
    '/post',
    authMiddleware,
    upload.single('prod_img'),
    [
        check('category').notEmpty().withMessage('Category is required'),
        check('product_name').notEmpty().withMessage('Product name is required'),
        check('price').isNumeric().withMessage('Valid price is required'),
        check('variations').optional().custom((value) => {
            try {
                JSON.parse(value);
                return true;
            } catch (error) {
                throw new Error('Variations must be a valid JSON string');
            }
        }),
    ],
    createProduct
);

router.get('/', authMiddleware, getVendorProducts);

router.get('/search', authMiddleware, searchProducts);

router.get('/count', authMiddleware, getProductCount);

router.post('/update', authMiddleware, updateProduct);

router.get('/:productId', authMiddleware, getProductById);

router.delete('/delete/:productId', authMiddleware, deleteProduct);

router.delete('/delete', authMiddleware, deleteMultipleProducts);

module.exports = router;