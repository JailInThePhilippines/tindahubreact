const express = require('express');
const { check } = require('express-validator');
const { getAllVendors, createVendor, verifyEmail, loginVendor, forgotPassword, resetPassword, updateVendorProfile, getVendorProfile, getVendorReviews, updateVendorInformation, updateVendorLogo } = require('../controllers/vendorController');
const passport = require('passport');
const authMiddleware = require('../middleware/authMiddleware');
const { upload } = require('../config/cloudinaryConfig');
const jwt = require('jsonwebtoken');

const router = express.Router();

router.post(
    '/auth/register',
    [
        check('vendor_name').notEmpty().withMessage('Vendor name is required'),
        check('vendor_email').isEmail().withMessage('Please provide a valid email'),
        check('password')
            .isLength({ min: 6 })
            .withMessage('Password must be at least 6 characters long'),
        check('contact_number').isMobilePhone().withMessage('Please provide a valid phone number'),
        check('location').notEmpty().withMessage('Location is required'),
        check('description').notEmpty().withMessage('Description is required'),
    ],
    createVendor
);

router.post(
    '/auth/login',
    [
        check('vendor_email').isEmail().withMessage('Please provide a valid email'),
        check('password').notEmpty().withMessage('Password is required'),
    ],
    loginVendor
);

router.post(
    '/auth/forgot-password',
    [check('email').isEmail().withMessage('Please provide a valid email')],
    forgotPassword
);

router.post(
    '/auth/reset-password',
    [
        check('token').notEmpty().withMessage('Reset token is required'),
        check('password')
            .isLength({ min: 6 })
            .withMessage('Password must be at least 6 characters long'),
    ],
    resetPassword
);


router.get('/', getAllVendors);

router.get('/information', authMiddleware, getVendorProfile);

router.get('/auth/verify-email', verifyEmail);

/* Google oAuth2 call */
router.get('/auth/google', 
    passport.authenticate('google', { 
        scope: ['profile', 'email']
    })
);

/* Google oAuth2 callback */
router.get(
    '/auth/google/callback',
    passport.authenticate('google', { 
        failureRedirect: 'https://tindahub.vercel.app/login?error=auth_failed',
        session: false
    }),
    async (req, res) => {
        try {
            const token = jwt.sign(
                {
                    vendorId: req.user.profile._id,
                    accountId: req.user.account._id,
                    email: req.user.account.vendor_email
                },
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );

            const isProfileComplete =
                req.user.profile.location !== 'Please update your location' &&
                req.user.profile.description !== 'Please update your profile description';

            const vendorData = {
                id: req.user.profile._id,
                accountId: req.user.account._id,
                vendor_name: req.user.profile.vendor_name,
                vendor_email: req.user.account.vendor_email,
                location: req.user.profile.location,
                rating: req.user.profile.rating,
                description: req.user.profile.description,
                operating_hours: req.user.profile.operating_hours,
                vendor_profile_image: req.user.profile.vendor_profile_image,
                isProfileComplete: isProfileComplete
            };

            const encodedVendorData = encodeURIComponent(JSON.stringify(vendorData));

            const frontendURL = 'http://localhost:5173';
            const redirectURL = isProfileComplete
                ? `${frontendURL}/auth/google/callback?token=${token}&vendor=${encodedVendorData}`
                : `${frontendURL}/complete-profile?token=${token}&vendor=${encodedVendorData}`;

            res.redirect(redirectURL);
        } catch (error) {
            console.error('Google callback error:', error);
            res.redirect('https://tindahub.vercel.app/login?error=auth_failed');
        }
    }
);

router.get('/auth/google/failure', (req, res) => {
    res.status(401).json({ message: 'Google Sign-In failed. Please try again.' });
});

router.put('/auth/profile', authMiddleware, updateVendorProfile);

router.get('/reviews', authMiddleware, getVendorReviews);

router.patch('/information/patch', authMiddleware, updateVendorInformation);

router.post('/profile/update', authMiddleware, upload.single('vendor_profile_image'), updateVendorLogo);

module.exports = router;