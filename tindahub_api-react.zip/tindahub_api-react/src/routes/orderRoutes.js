const express = require('express');
const router = express.Router();
const { getOrders, getCompletedOrders, getOrderIssues, updateOrderStatus, updateReportStatus } = require('../controllers/orderController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', authMiddleware, getOrders);

router.get('/completed', authMiddleware, getCompletedOrders);

router.get('/issues', authMiddleware, getOrderIssues);

router.post('/update', authMiddleware, updateOrderStatus);

router.patch('/issues/reportstatus/patch', authMiddleware, updateReportStatus);

module.exports = router;