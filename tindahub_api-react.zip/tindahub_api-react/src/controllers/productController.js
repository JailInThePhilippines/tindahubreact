const Product = require('../models/productModel');
const ProductVariation = require('../models/productVariationsModel');
const ProductReview = require('../models/productReviewsModel');
const { validationResult } = require('express-validator');
const { cloudinary } = require('../config/cloudinaryConfig');
const { encrypt } = require('../middleware/crypto');
const DatauriParser = require('datauri/parser');
const path = require('path');
const parser = new DatauriParser();
const fs = require('fs');

const bufferToDataURI = (fileBuffer, fileType) => {
    const fileExtension = path.extname(fileType).toString();
    return parser.format(fileExtension, fileBuffer);
};

exports.createProduct = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).send(encrypt({
                success: false,
                errors: errors.array()
            }));
        }

        let imageUrl = null;
        if (req.file) {
            const file = bufferToDataURI(req.file.buffer, req.file.originalname).content;
            const result = await cloudinary.uploader.upload(file, {
                folder: 'products',
                transformation: [{ width: 500, height: 500, crop: 'limit' }]
            });
            imageUrl = result.secure_url;
        }

        const {
            category,
            product_name,
            description,
            price,
            availability,
            quantity,
            track_quantity
        } = req.body;

        const product = new Product({
            vendor_id: req.user.accountId,
            category,
            product_name,
            description,
            price: parseFloat(price),
            availability: availability ?? true,
            quantity: quantity || null,
            track_quantity: track_quantity ?? false,
            prod_img: imageUrl,
            date: new Date()
        });

        const savedProduct = await product.save();

        let savedVariations = [];
        if (req.body.variations) {
            try {
                const variations = JSON.parse(req.body.variations);
                if (Array.isArray(variations) && variations.length > 0) {
                    const variationDocs = variations.map(variation => ({
                        product_id: savedProduct._id,
                        variation_name: variation.variation_name,
                        price: parseFloat(variation.price),
                        stock: variation.stock || 0,
                    }));
                    savedVariations = await ProductVariation.insertMany(variationDocs);
                }
            } catch (error) {
                console.error('Error processing variations:', error);
            }
        }

        res.status(201).send(encrypt({
            success: true,
            message: "Product created successfully",
            data: {
                product: savedProduct,
                variations: savedVariations
            }
        }));

    } catch (error) {
        console.error('Error in createProduct:', error);
        res.status(500).send(encrypt({
            success: false,
            message: "Error creating product",
            error: error.message
        }));
    }
};

exports.getVendorProducts = async (req, res) => {
    try {
        const accountId = req.user.accountId;

        const products = await Product.find({ vendor_id: accountId }).lean();

        const productData = await Promise.all(products.map(async (product) => {
            const variations = await ProductVariation.find({ product_id: product._id }).lean();
            const reviews = await ProductReview.find({ product_id: product._id })
                .populate('user_id', 'name')
                .lean();

            const formattedReviews = reviews.map(review => ({
                review_id: review._id,
                rating: review.rating.toFixed(1),
                comment: review.comment,
                review_date: review.review_date.toISOString().replace('T', ' ').split('.')[0],
                user_id: review.user_id._id,
                reviewer_name: review.user_id.name
            }));

            return {
                product_id: product._id,
                vendor_id: product.vendor_id,
                category: product.category,
                product_name: product.product_name,
                description: product.description,
                price: product.price.toFixed(2),
                availability: product.availability,
                prod_img: product.prod_img,
                date: product.date.toISOString().split('T')[0],
                quantity: product.quantity || 0,
                track_quantity: product.track_quantity ? 1 : 0,
                variations,
                reviews: formattedReviews
            };
        }));

        res.status(200).send(encrypt({
            success: true,
            data: productData
        }));
    } catch (error) {
        console.error('Error fetching vendor products:', error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error fetching products',
            error: error.message
        }));
    }
};

exports.searchProducts = async (req, res) => {
    try {
        const accountId = req.user.accountId;
        const searchTerm = req.query.q ? req.query.q.trim() : "";
        const category = req.query.category ? req.query.category.trim() : null;

        let query = { vendor_id: accountId };
        if (searchTerm) {
            query.product_name = { $regex: searchTerm, $options: "i" };
        }
        if (category) {
            query.category = category;
        }

        const products = await Product.find(query).lean();

        if (!products.length) {
            return res.status(404).send(encrypt({
                success: false,
                message: "No products found matching the search criteria"
            }));
        }

        const productIds = products.map(p => p._id);
        const variations = await ProductVariation.find({ product_id: { $in: productIds } }).lean();
        const reviews = await ProductReview.find({ product_id: { $in: productIds } })
            .populate('user_id', 'name')
            .lean();

        const productMap = {};
        products.forEach(product => {
            productMap[product._id] = {
                product_id: product._id,
                vendor_id: product.vendor_id,
                category: product.category,
                product_name: product.product_name,
                description: product.description,
                price: product.price.toFixed(2),
                availability: product.availability ? 1 : 0,
                prod_img: product.prod_img,
                date: product.date.toISOString().split("T")[0],
                quantity: product.quantity || 0,
                track_quantity: product.track_quantity ? 1 : 0,
                variations: [],
                reviews: []
            };
        });

        variations.forEach(variation => {
            if (productMap[variation.product_id]) {
                productMap[variation.product_id].variations.push({
                    variation_id: variation._id,
                    variation_name: variation.variation_name,
                    price: variation.price.toFixed(2),
                    stock: variation.stock || 0
                });
            }
        });

        reviews.forEach(review => {
            if (productMap[review.product_id]) {
                productMap[review.product_id].reviews.push({
                    review_id: review._id,
                    reviewer_name: review.user_id.name,
                    review_date: review.review_date.toISOString().replace("T", " ").split(".")[0],
                    rating: review.rating.toFixed(1),
                    comment: review.comment
                });
            }
        });

        res.status(200).send(encrypt({
            success: true,
            data: Object.values(productMap)
        }));

    } catch (error) {
        console.error("Error in searchProducts:", error);
        res.status(500).send(encrypt({
            success: false,
            message: "An error occurred while searching for products"
        }));
    }
};

exports.getProductCount = async (req, res) => {
    try {
        const accountId = req.user.accountId;

        if (!accountId) {
            return res.status(401).send(encrypt({ success: false, message: "Unauthorized access" }));
        }

        const productCount = await Product.countDocuments({ vendor_id: accountId });

        res.status(200).send(encrypt({
            success: true,
            product_count: productCount
        }));

    } catch (error) {
        console.error("Error fetching product count:", error);
        res.status(500).send(encrypt({
            success: false,
            message: "An error occurred while fetching the product count"
        }));
    }
};

exports.updateProduct = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).send(encrypt({
                success: false,
                errors: errors.array()
            }));
        }

        const {
            product_id,
            category,
            product_name,
            description,
            price,
            availability,
            quantity
        } = req.body;

        if (!product_id) {
            return res.status(400).send(encrypt({
                success: false,
                message: "Product ID is required"
            }));
        }

        let imageUrl = null;
        if (req.file) {
            const file = bufferToDataURI(req.file.buffer, req.file.originalname).content;
            const result = await cloudinary.uploader.upload(file, {
                folder: 'products',
                transformation: [{ width: 500, height: 500, crop: 'limit' }]
            });
            imageUrl = result.secure_url;
        }

        const updatedProduct = await Product.findOneAndUpdate(
            { _id: product_id, vendor_id: req.user.accountId },
            {
                category,
                product_name,
                description,
                price: parseFloat(price),
                availability: availability || true,
                quantity: quantity || null,
                prod_img: imageUrl || undefined,
                date: new Date()
            },
            { new: true }
        );

        if (!updatedProduct) {
            return res.status(404).send(encrypt({
                success: false,
                message: "Product not found"
            }));
        }

        res.status(200).send(encrypt({
            success: true,
            message: "Product updated successfully",
            data: updatedProduct
        }));

    } catch (error) {
        console.error('Error in updateProduct:', error);
        res.status(500).send(encrypt({
            success: false,
            message: "Error updating product",
            error: error.message
        }));
    }
};

exports.getProductById = async (req, res) => {
    try {
        const productId = req.params.productId;
        const accountId = req.user.accountId;

        if (!accountId) {
            return res.status(401).send(encrypt({
                success: false,
                message: "Unauthorized access"
            }));
        }

        const product = await Product.findOne({
            _id: productId,
            vendor_id: accountId
        }).lean();

        if (!product) {
            return res.status(404).send(encrypt({
                success: false,
                message: "Product not found"
            }));
        }

        const formattedProduct = {
            product_id: product._id,
            vendor_id: product.vendor_id,
            category: product.category,
            product_name: product.product_name,
            description: product.description,
            price: product.price.toFixed(2),
            availability: product.availability,
            prod_img: product.prod_img,
            date: product.date.toISOString().split('T')[0],
            quantity: product.quantity || 0,
            track_quantity: product.track_quantity ? 1 : 0
        };

        const variations = await ProductVariation.find({ product_id: productId }).lean();
        const reviews = await ProductReview.find({ product_id: productId })
            .populate('user_id', 'name')
            .lean();

        const formattedReviews = reviews.map(review => ({
            review_id: review._id,
            rating: review.rating.toFixed(1),
            comment: review.comment,
            review_date: review.review_date.toISOString().replace('T', ' ').split('.')[0],
            user_id: review.user_id._id,
            reviewer_name: review.user_id.name
        }));

        formattedProduct.variations = variations;
        formattedProduct.reviews = formattedReviews;

        res.status(200).send(encrypt({
            success: true,
            data: formattedProduct
        }));

    } catch (error) {
        console.error('Error in getProductById:', error);
        res.status(500).send(encrypt({
            success: false,
            message: "Error fetching product",
            error: error.message
        }));
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        const productId = req.params.productId;
        const vendorId = req.user.accountId;

        if (!productId || !vendorId) {
            return res.status(400).send(encrypt({ success: false, message: "Invalid product ID or unauthorized access" }));
        }

        const product = await Product.findOne({ _id: productId, vendor_id: vendorId });
        if (!product) {
            return res.status(404).send(encrypt({ success: false, message: "Product not found or not owned by this vendor" }));
        }

        if (product.prod_img && fs.existsSync(product.prod_img)) {
            fs.unlinkSync(product.prod_img);
        }

        await Product.deleteOne({ _id: productId, vendor_id: vendorId });

        res.status(200).send(encrypt({ success: true, message: "Product deleted successfully" }));
    } catch (error) {
        console.error("Error deleting product:", error);
        res.status(500).send(encrypt({ success: false, message: "An error occurred while deleting the product" }));
    }
};

exports.deleteMultipleProducts = async (req, res) => {
    try {
        const vendorId = req.user.accountId;
        const productIds = req.body.product_ids;

        if (!Array.isArray(productIds) || productIds.length === 0) {
            return res.status(400).send(encrypt({ success: false, message: "No product IDs provided" }));
        }

        const products = await Product.find({ _id: { $in: productIds }, vendor_id: vendorId });

        if (products.length !== productIds.length) {
            return res.status(404).send(encrypt({ success: false, message: "One or more products not found or not owned by this vendor" }));
        }

        for (const product of products) {
            if (product.prod_img) {
                await cloudinary.uploader.destroy(product.prod_img);
            }
        }

        await Product.deleteMany({ _id: { $in: productIds }, vendor_id: vendorId });

        res.status(200).send(encrypt({ success: true, message: "Products deleted successfully" }));
    } catch (error) {
        console.error("Error in deleteMultipleProducts:", error);
        res.status(500).send(encrypt({ success: false, message: "An error occurred while deleting products", error: error.message }));
    }
};
