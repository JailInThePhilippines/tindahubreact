const { encrypt } = require('../middleware/crypto');
const Order = require('../models/orderModel');
const OrderItem = require('../models/orderItemsModel');
const Product = require('../models/productModel');
const mongoose = require("mongoose");

// Helper functions
const validateUserAccess = (accountId, vendorId) => {
    if (!accountId || !vendorId) {
        const error = new Error("Unauthorized access");
        error.status = 401;
        throw error;
    }
};

const validateDateRange = (startDate, endDate) => {
    if (startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);

        if (isNaN(start) || isNaN(end)) {
            const error = new Error("Invalid date format. Please use 'YYYY-MM-DD'");
            error.status = 400;
            throw error;
        }

        if (start > end) {
            const error = new Error("start_date cannot be later than end_date");
            error.status = 400;
            throw error;
        }

        return { start, end };
    }

    return {
        start: new Date(new Date().setMonth(new Date().getMonth() - 3)),
        end: new Date()
    };
};

const handleResponse = (res, data, status = 200) => {
    return res.status(status).send(encrypt({
        success: true,
        data
    }));
};

const handleError = (res, error) => {
    console.error(`Error: ${error.message}`);
    const status = error.status || 500;
    const message = error.status ? error.message : "An internal server error occurred";

    return res.status(status).send(encrypt({
        success: false,
        message,
        ...(status === 500 && { error: error.message })
    }));
};

// Aggregation pipelines
const salesAggregationPipeline = (matchCriteria, groupBy, sortBy) => [
    { $match: matchCriteria },
    { $group: groupBy },
    { $sort: sortBy }
];

const productAggregationPipeline = (orderIds, limit = 10) => [
    {
        $match: { order_id: { $in: orderIds } }
    },
    {
        $lookup: {
            from: "orders",
            localField: "order_id",
            foreignField: "_id",
            as: "order"
        }
    },
    { $unwind: { path: "$order", preserveNullAndEmptyArrays: true } },
    {
        $lookup: {
            from: "products",
            localField: "product_id",
            foreignField: "_id",
            as: "product"
        }
    },
    { $unwind: { path: "$product", preserveNullAndEmptyArrays: true } },
    {
        $group: {
            _id: "$product._id",
            product_name: { $first: "$product.product_name" },
            prod_img: { $first: "$product.prod_img" },
            total_quantity: { $sum: "$quantity" }
        }
    },
    { $sort: { total_quantity: -1 } },
    { $limit: limit }
];

exports.getMonthlySales = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const vendorObjectId = new mongoose.Types.ObjectId(accountId);

        const matchCriteria = {
            vendor_id: vendorObjectId,
            order_status: "completed"
        };

        const groupBy = {
            _id: {
                year: { $year: "$order_date" },
                month: { $month: "$order_date" }
            },
            total_sales: { $sum: "$total_amount" }
        };

        const sortBy = { "_id.year": -1, "_id.month": -1 };

        const salesData = await Order.aggregate([
            { $match: matchCriteria },
            { $group: groupBy },
            { $sort: sortBy }
        ]);

        const formattedSales = salesData.map(sale => ({
            year: sale._id.year,
            month: sale._id.month,
            total_sales: sale.total_sales
        }));

        if (!formattedSales.length) {
            const error = new Error("No sales data found for this vendor");
            error.status = 404;
            throw error;
        }

        handleResponse(res, formattedSales);
    } catch (error) {
        handleError(res, error);
    }
};

exports.getWeeklySales = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const vendorObjectId = new mongoose.Types.ObjectId(accountId);

        const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();

        const matchCriteria = {
            vendor_id: vendorObjectId,
            order_status: "completed",
            order_date: {
                $gte: startDate,
                $lte: endDate
            }
        };

        const groupBy = {
            _id: {
                year: { $year: "$order_date" },
                week: { $week: "$order_date" }
            },
            total_sales: { $sum: "$total_amount" }
        };

        const sortBy = { "_id.year": -1, "_id.week": -1 };

        const salesData = await Order.aggregate([
            { $match: matchCriteria },
            { $group: groupBy },
            { $sort: sortBy }
        ]);

        const formattedSales = salesData.map(sale => ({
            year: sale._id.year,
            week: sale._id.week,
            total_sales: sale.total_sales
        }));

        handleResponse(res, formattedSales);
    } catch (error) {
        handleError(res, error);
    }
};

exports.getMostOrderedProducts = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const orders = await Order.find({
            vendor_id: accountId,
            order_status: "completed"
        });

        if (!orders.length) {
            const error = new Error("No completed orders found for this vendor");
            error.status = 404;
            throw error;
        }

        const orderIds = orders.map(order => order._id);
        const results = await OrderItem.aggregate(productAggregationPipeline(orderIds, 10));

        if (!results.length) {
            const error = new Error("No products found for this vendor");
            error.status = 404;
            throw error;
        }

        handleResponse(res, results);
    } catch (error) {
        handleError(res, error);
    }
};

exports.getMostOrderedProduct = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const orders = await Order.find({
            vendor_id: accountId,
            order_status: "completed"
        });

        if (!orders.length) {
            const error = new Error("No completed orders found for this vendor");
            error.status = 404;
            throw error;
        }

        const orderIds = orders.map(order => order._id);
        const results = await OrderItem.aggregate(productAggregationPipeline(orderIds, 1));

        if (!results.length) {
            const error = new Error("No products found for this vendor");
            error.status = 404;
            throw error;
        }

        handleResponse(res, results[0]);
    } catch (error) {
        handleError(res, error);
    }
};

exports.getAllSalesReports = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const vendorObjectId = new mongoose.Types.ObjectId(accountId);
        const startDate = new Date(new Date().setMonth(new Date().getMonth() - 3));
        const endDate = new Date();

        const [weeklySales, monthlySales, mostOrderedProducts] = await Promise.all([
            // Weekly sales aggregation
            Order.aggregate(salesAggregationPipeline(
                {
                    vendor_id: vendorObjectId,
                    order_status: "completed",
                    order_date: { $gte: startDate, $lte: endDate }
                },
                {
                    _id: {
                        year: { $year: "$order_date" },
                        week: { $isoWeek: "$order_date" }
                    },
                    total_sales: { $sum: "$total_amount" }
                },
                { "_id.year": -1, "_id.week": -1 }
            )),
            // Monthly sales aggregation
            Order.aggregate(salesAggregationPipeline(
                {
                    vendor_id: vendorObjectId,
                    order_status: "completed"
                },
                {
                    _id: {
                        year: { $year: "$order_date" },
                        month: { $month: "$order_date" }
                    },
                    total_sales: { $sum: "$total_amount" }
                },
                { "_id.year": -1, "_id.month": -1 }
            )),
            // Most ordered products aggregation
            OrderItem.aggregate([
                {
                    $lookup: {
                        from: "orders",
                        localField: "order_id",
                        foreignField: "_id",
                        as: "order"
                    }
                },
                { $unwind: "$order" },
                {
                    $match: {
                        "order.vendor_id": vendorObjectId,
                        "order.order_status": "completed"
                    }
                },
                {
                    $lookup: {
                        from: "products",
                        localField: "product_id",
                        foreignField: "_id",
                        as: "product"
                    }
                },
                { $unwind: "$product" },
                {
                    $group: {
                        _id: "$product._id",
                        product_name: { $first: "$product.product_name" },
                        prod_img: { $first: "$product.prod_img" },
                        total_quantity: { $sum: "$quantity" }
                    }
                },
                { $sort: { total_quantity: -1 } },
                { $limit: 10 }
            ])
        ]);

        const allReports = {
            weekly_sales: weeklySales.map(sale => ({
                year: sale._id.year,
                week: sale._id.week,
                total_sales: sale.total_sales
            })),
            monthly_sales: monthlySales.map(sale => ({
                year: sale._id.year,
                month: sale._id.month,
                total_sales: sale.total_sales
            })),
            most_ordered_products: mostOrderedProducts,
            most_ordered_product: mostOrderedProducts.length ? mostOrderedProducts[0] : null
        };

        handleResponse(res, allReports);
    } catch (error) {
        handleError(res, error);
    }
};

exports.getTotalOrdersAndRevenue = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        validateUserAccess(accountId, vendorId);

        const vendorObjectId = new mongoose.Types.ObjectId(accountId);

        const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(new Date().setDate(1));
        startDate.setHours(0, 0, 0, 0);

        const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
        endDate.setHours(23, 59, 59, 999);

        console.log('Backend Start Date:', startDate);
        console.log('Backend End Date:', endDate);

        const totalOrdersAndRevenue = await Order.aggregate([
            {
                $match: {
                    vendor_id: vendorObjectId,
                    order_status: "completed",
                    order_date: {
                        $gte: startDate,
                        $lte: endDate
                    }
                }
            },
            {
                $group: {
                    _id: null,
                    total_orders: { $sum: 1 },
                    total_revenue: { $sum: "$total_amount" }
                }
            }
        ]);

        if (!totalOrdersAndRevenue.length) {
            return handleResponse(res, { total_orders: 0, total_revenue: 0 });
        }

        handleResponse(res, totalOrdersAndRevenue[0]);
    } catch (error) {
        handleError(res, error);
    }
};