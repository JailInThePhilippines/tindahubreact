const { encrypt } = require('../middleware/crypto');
const Order = require('../models/orderModel');
const OrderItem = require('../models/orderItemsModel');
const Vendor = require('../models/vendorModel');
const OrderIssueReport = require('../models/orderIssueModel');
const OrderStatusHistory = require('../models/orderHistoryModel');
const User = require('../models/userModel');
const mongoose = require("mongoose");

// Helper functions
const validateUserAccess = async (accountId, vendorId) => {
    if (!accountId || !vendorId) {
        const error = new Error("Unauthorized access");
        error.status = 401;
        throw error;
    }

    const vendor = await Vendor.findOne({ _id: vendorId, vendor_id: accountId }).lean();
    if (!vendor) {
        const error = new Error("Vendor not found");
        error.status = 404;
        throw error;
    }
    return vendor;
};

const handleResponse = (res, data, status = 200) => {
    return res.status(status).send(encrypt({
        success: true,
        data
    }));
};

const handleError = (res, error) => {
    console.error(`Error: ${error.message}`);
    const status = error.status || 500;
    const message = error.status ? error.message : "An internal server error occurred";

    return res.status(status).send(encrypt({
        success: false,
        message,
        ...(status === 500 && { error: error.message })
    }));
};

// Order processing helpers
const processOrders = (orders, orderItems) => {
    const groupedOrders = {};

    orders.forEach(order => {
        if (!order?._id) return;

        groupedOrders[order._id] = {
            order_id: order._id,
            user_id: order.user_id?._id || null,
            vendor_id: order.vendor_id,
            total_amount: order.total_amount || 0,
            pickup_time: order.pickup_time || null,
            order_status: order.order_status || 'pending',
            name: order.user_id?.name || 'Unknown User',
            email: order.user_id?.email || 'No email provided',
            order_date: formatDate(order.order_date),
            special_instruction: order.special_instruction || '',
            isPaid: order.isPaid || false,
            mode_of_payment: order.mode_of_payment || 'Unknown',
            payment_id: order.payment_id || 'N/A',
            products: []
        };
    });

    orderItems.forEach(item => {
        if (!item?.order_id || !groupedOrders[item.order_id] || !item.product_id) return;

        groupedOrders[item.order_id].products.push({
            orderitem_id: item._id || null,
            product_id: item.product_id._id || null,
            quantity: item.quantity || 0,
            unit_price: item.unit_price || 0,
            special_instruction: item.special_instruction || '',
            product_name: item.product_id.product_name || 'Unknown Product',
            description: item.product_id.description || '',
            price: item.product_id.price || 0,
            prod_img: item.product_id.prod_img || null,
            category: item.product_id.category || 'Uncategorized'
        });
    });

    return Object.values(groupedOrders).filter(order => order && order.order_id);
};

const formatDate = (date) => {
    return date ?
        date.toISOString().replace('T', ' ').split('.')[0] :
        new Date().toISOString().replace('T', ' ').split('.')[0];
};

// Controller functions
exports.getOrders = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        await validateUserAccess(accountId, vendorId);

        const orders = await Order.find({
            vendor_id: accountId,
            order_status: { $ne: "completed" }
        })
            .populate({
                path: 'user_id',
                select: 'name email'
            })
            .lean();

        if (!orders?.length) {
            const error = new Error("No orders found for this vendor");
            error.status = 404;
            throw error;
        }

        const orderItems = await OrderItem.find({
            order_id: { $in: orders.map(order => order._id) }
        })
            .populate({
                path: 'product_id',
                select: 'product_name description price prod_img category'
            })
            .lean();

        const processedOrders = processOrders(orders, orderItems);
        handleResponse(res, processedOrders);

    } catch (error) {
        handleError(res, error);
    }
};

exports.getCompletedOrders = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        await validateUserAccess(accountId, vendorId);

        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.per_page) || 10;
        const skip = (page - 1) * perPage;

        const [orders, totalOrders] = await Promise.all([
            Order.find({
                vendor_id: accountId,
                order_status: "completed"
            })
                .populate({
                    path: 'user_id',
                    select: 'name email'
                })
                .skip(skip)
                .limit(perPage)
                .lean(),

            Order.countDocuments({
                vendor_id: accountId,
                order_status: "completed"
            })
        ]);

        if (!orders?.length) {
            const error = new Error("No completed orders found for this vendor");
            error.status = 404;
            throw error;
        }

        const orderItems = await OrderItem.find({
            order_id: { $in: orders.map(order => order._id) }
        })
            .populate({
                path: 'product_id',
                select: 'product_name description price prod_img category'
            })
            .lean();

        const processedOrders = processOrders(orders, orderItems);

        handleResponse(res, {
            orders: processedOrders,
            page,
            per_page: perPage,
            total: totalOrders
        });

    } catch (error) {
        handleError(res, error);
    }
};

exports.getOrderIssues = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        await validateUserAccess(accountId, vendorId);

        const orderIssues = await OrderIssueReport.find({
            status: { $ne: "resolved" }
        })
            .populate({
                path: "user_id",
                select: "name email"
            })
            .populate({
                path: "order_id",
                select: "_id order_date total_amount"
            })
            .lean();

        if (!orderIssues?.length) {
            const error = new Error("No unresolved order issues found");
            error.status = 404;
            throw error;
        }

        const orderItems = await OrderItem.find({
            order_id: { $in: orderIssues.map(issue => issue.order_id._id) }
        })
            .populate({
                path: "product_id",
                select: "product_name description prod_img price"
            })
            .lean();

        const formattedIssues = orderIssues.map(issue => ({
            report_id: issue._id,
            order_id: issue.order_id._id,
            issue_type: issue.issue_type,
            additional_details: issue.additional_details,
            report_date: issue.report_date,
            status: issue.status,
            resolved_date: issue.resolved_date || null,
            reporter_name: issue.user_id?.name || "Unknown",
            reporter_email: issue.user_id?.email || "Unknown",
            order_items: orderItems
                .filter(item => item.order_id.toString() === issue.order_id._id.toString())
                .map(item => ({
                    orderitem_id: item._id,
                    product_id: item.product_id?._id,
                    quantity: item.quantity,
                    unit_price: item.unit_price,
                    special_instruction: item.special_instruction,
                    product_name: item.product_id?.product_name,
                    product_description: item.product_id?.description,
                    product_price: item.product_id?.price,
                    prod_img: item.product_id?.prod_img
                }))
        }));

        handleResponse(res, formattedIssues);

    } catch (error) {
        handleError(res, error);
    }
};

exports.updateOrderStatus = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { accountId, vendorId } = req.user;
        const { order_id, order_status } = req.body;

        await validateUserAccess(accountId, vendorId);

        if (!order_id || !order_status) {
            const error = new Error("Validation error");
            error.status = 400;
            error.details = {
                order_id: !order_id ? "Valid order ID is required" : undefined,
                order_status: !order_status ? "Order status is required" : undefined
            };
            throw error;
        }

        const order = await Order.findById(order_id).session(session);
        if (!order) {
            const error = new Error("Order not found");
            error.status = 404;
            throw error;
        }

        order.order_status = order_status;
        await order.save({ session });

        if (order_status === "completed") {
            const orderItems = await OrderItem.find({ order_id })
                .populate('product_id')
                .session(session);

            for (const item of orderItems) {
                const product = item.product_id;
                if (product.track_quantity) {
                    if (product.quantity < item.quantity) {
                        throw new Error(`Insufficient stock for product ID ${product._id}`);
                    }
                    product.quantity -= item.quantity;
                    await product.save({ session });
                }
            }
        }

        await OrderStatusHistory.create([{
            order_id,
            status: order_status,
            status_timestamp: new Date()
        }], { session });

        await session.commitTransaction();
        handleResponse(res, { message: "Order status updated successfully" });

    } catch (error) {
        await session.abortTransaction();
        handleError(res, error);
    } finally {
        session.endSession();
    }
};

exports.updateReportStatus = async (req, res) => {
    try {
        const { accountId, vendorId } = req.user;
        await validateUserAccess(accountId, vendorId);

        const { report_id, status } = req.body;

        const validationErrors = {};
        if (!report_id) {
            validationErrors.report_id = "Report ID is required";
        }
        if (!status) {
            validationErrors.status = "Status is required";
        }

        if (Object.keys(validationErrors).length > 0) {
            const error = new Error("Validation error");
            error.status = 400;
            error.details = validationErrors;
            throw error;
        }

        const report = await OrderIssueReport.findById(report_id).lean();

        if (!report) {
            const error = new Error("Report not found");
            error.status = 404;
            throw error;
        }

        const updateData = {
            status: status
        };

        if (status === 'resolved') {
            updateData.resolved_date = new Date();
        }

        const updatedReport = await OrderIssueReport.findByIdAndUpdate(
            report_id,
            updateData,
            { new: true }
        );

        if (!updatedReport) {
            const error = new Error("Failed to update report status");
            error.status = 400;
            throw error;
        }

        handleResponse(res, {
            success: true,
            message: "Report status updated successfully"
        });

    } catch (error) {
        handleError(res, error);
    }
};