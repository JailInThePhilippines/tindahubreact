const { validationResult } = require('express-validator');
const { encrypt } = require('../middleware/crypto')
const mongoose = require("mongoose");
const bcrypt = require('bcryptjs');
const Vendor = require('../models/vendorModel');
const VendorAccount = require('../models/vendorAccountModel');
const Review = require('../models/reviewsModel');
const nodemailer = require('nodemailer');
const generateToken = require('../utils/generateToken');
const jwt = require('jsonwebtoken')
const DatauriParser = require('datauri/parser');
const { cloudinary } = require('../config/cloudinaryConfig');
const path = require('path');

const parser = new DatauriParser();

const bufferToDataURI = (fileBuffer, fileType) => {
    const fileExtension = path.extname(fileType).toString();
    return parser.format(fileExtension, fileBuffer);
};

/* Get all vendors */
exports.getAllVendors = async (req, res) => {
    try {
        const vendors = await Vendor.find();
        res.status(200).send(encrypt({
            success: true,
            data: vendors
        }));
    } catch (error) {
        res.status(500).send(encrypt({
            success: false,
            message: 'Error fetching vendors'
        }));
    }
};

/* Create a new vendor */
exports.createVendor = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).send(encrypt({
            success: false,
            errors: errors.array()
        }));
    }

    try {
        const {
            vendor_name,
            vendor_email,
            password,
            contact_number,
            location,
            description,
            operating_hours,
            business_permit
        } = req.body;

        const existingAccount = await VendorAccount.findOne({ vendor_email });
        if (existingAccount) {
            if (existingAccount.googleId) {
                return res.status(400).send(encrypt({
                    success: false,
                    message: 'This email is registered via Google. Please sign in with Google.'
                }));
            }
            return res.status(400).send(encrypt({
                success: false,
                message: 'Email is already in use.'
            }));
        }

        const newVendorAccount = new VendorAccount({
            vendor_name,
            vendor_email,
            password,
            contact_number
        });

        const savedVendorAccount = await newVendorAccount.save();

        const newVendor = new Vendor({
            vendor_id: savedVendorAccount._id,
            vendor_name,
            email: vendor_email,
            location,
            description,
            operating_hours,
            business_permit,
            vendor_profile_image: req.body.vendor_profile_image || ''
        });

        const emailVerificationToken = generateToken();
        newVendor.emailVerificationToken = emailVerificationToken;
        newVendor.emailVerificationTokenExpires = Date.now() + 24 * 60 * 60 * 1000;

        await newVendor.save();

        // Email configuration remains unencrypted as it's internal
        const transporter = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS,
            },
        });

        const verificationUrl = `${process.env.CLIENT_URL}/api/vendors/auth/verify-email?token=${emailVerificationToken}`;
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: vendor_email,
            subject: 'Email Verification',
            html: `
                <h1>Verify Your Email</h1>
                <p>Please verify your email by clicking the link below:</p>
                <a href="${verificationUrl}">${verificationUrl}</a>
            `,
        });

        res.status(201).send(encrypt({
            success: true,
            message: 'Account created successfully. Please check your email to verify your account.'
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error creating account'
        }));
    }
};
exports.verifyEmail = async (req, res) => {
    const { token } = req.query;

    try {
        const vendor = await Vendor.findOne({
            emailVerificationToken: token,
            emailVerificationTokenExpires: { $gt: Date.now() },
        });

        if (!vendor) {
            return res.status(400).send(encrypt({
                success: false,
                message: 'Invalid or expired token'
            }));
        }

        vendor.emailVerified = true;
        vendor.emailVerificationToken = undefined;
        vendor.emailVerificationTokenExpires = undefined;

        await vendor.save();

        res.status(200).send(encrypt({
            success: true,
            message: 'Email verified successfully'
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error verifying email'
        }));
    }
};

exports.loginVendor = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).send(encrypt({
            success: false,
            errors: errors.array()
        }));
    }

    try {
        const { vendor_email, password } = req.body;

        const vendorAccount = await VendorAccount.findOne({ vendor_email });
        if (!vendorAccount) {
            return res.status(400).send(encrypt({
                success: false,
                message: 'Invalid email or password'
            }));
        }

        const vendor = await Vendor.findOne({ vendor_id: vendorAccount._id });
        if (!vendor) {
            return res.status(400).send(encrypt({
                success: false,
                message: 'Vendor profile not found'
            }));
        }

        const isMatch = await bcrypt.compare(password, vendorAccount.password);
        if (!isMatch) {
            return res.status(400).send(encrypt({
                success: false,
                message: 'Invalid email or password'
            }));
        }

        if (!vendor.emailVerified) {
            return res.status(401).send(encrypt({
                success: false,
                message: 'Please verify your email before logging in'
            }));
        }

        const token = jwt.sign(
            {
                vendorId: vendor._id,
                accountId: vendorAccount._id,
                email: vendorAccount.vendor_email
            },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        res.status(200).send(encrypt({
            success: true,
            data: {
                token,
                vendor: {
                    id: vendor._id,
                    accountId: vendorAccount._id,
                    vendor_name: vendor.vendor_name,
                    vendor_email: vendorAccount.vendor_email,
                    location: vendor.location,
                    rating: vendor.rating,
                    description: vendor.description,
                    operating_hours: vendor.operating_hours,
                    vendor_profile_image: vendor.vendor_profile_image
                }
            }
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error logging in'
        }));
    }
};

exports.forgotPassword = async (req, res) => {
    const { vendor_email } = req.body;

    try {
        const vendorAccount = await VendorAccount.findOne({ vendor_email });
        if (!vendorAccount) {
            return res.status(404).send(encrypt({
                success: false,
                message: 'No vendor found with this email address.'
            }));
        }

        const resetPasswordToken = generateToken();
        vendorAccount.resetPasswordToken = resetPasswordToken;
        vendorAccount.resetPasswordExpires = Date.now() + 3600000;
        await vendorAccount.save();

        const transporter = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS,
            },
        });

        const resetUrl = `${process.env.CLIENT_URL}/api/vendors/auth/reset-password?token=${resetPasswordToken}`;
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: vendorAccount.vendor_email,
            subject: 'Password Reset Request',
            html: `
                <h1>Password Reset</h1>
                <p>You requested to reset your password. Click the link below to reset it:</p>
                <a href="${resetUrl}">${resetUrl}</a>
                <p>If you did not request this, please ignore this email.</p>
            `,
        });

        res.status(200).send(encrypt({
            success: true,
            message: 'Password reset email sent successfully.'
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error sending password reset email.'
        }));
    }
};

exports.resetPassword = async (req, res) => {
    const { token, password } = req.body;

    try {
        const vendorAccount = await VendorAccount.findOne({
            resetPasswordToken: token,
            resetPasswordExpires: { $gt: Date.now() },
        });

        if (!vendorAccount) {
            return res.status(400).send(encrypt({
                success: false,
                message: 'Invalid or expired reset token.'
            }));
        }

        vendorAccount.password = password;
        vendorAccount.resetPasswordToken = undefined;
        vendorAccount.resetPasswordExpires = undefined;

        await vendorAccount.save();

        res.status(200).send(encrypt({
            success: true,
            message: 'Password reset successfully.'
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error resetting password.'
        }));
    }
};
exports.updateVendorProfile = async (req, res) => {
    try {
        const {
            vendor_name,
            location,
            description,
            operating_hours,
            contact_number
        } = req.body;

        const vendor = await Vendor.findByIdAndUpdate(
            req.user.vendorId,
            {
                vendor_name,
                location,
                description,
                operating_hours
            },
            { new: true }
        );

        const vendorAccount = await VendorAccount.findByIdAndUpdate(
            req.user.accountId,
            {
                vendor_name,
                contact_number
            },
            { new: true }
        );

        res.status(200).send(encrypt({
            success: true,
            data: {
                message: 'Profile updated successfully',
                vendor: {
                    ...vendor.toObject(),
                    vendor_email: vendorAccount.vendor_email,
                    contact_number: vendorAccount.contact_number
                }
            }
        }));
    } catch (error) {
        console.error(error);
        res.status(500).send(encrypt({
            success: false,
            message: 'Error updating profile'
        }));
    }
};

exports.getVendorProfile = async (req, res) => {
    try {
        const { vendorId, accountId } = req.user;

        const vendor = await Vendor.findById(vendorId);
        const vendorAccount = await VendorAccount.findById(accountId);

        if (!vendor || !vendorAccount) {
            return res.status(404).json(
                encrypt({
                    success: false,
                    message: 'Vendor profile not found'
                })
            );
        }

        const vendorProfile = {
            vendor_id: vendor._id,
            vendor_name: vendorAccount.vendor_name,
            vendor_email: vendorAccount.vendor_email,
            contact_number: vendorAccount.contact_number,
            date_registered: vendorAccount.date_registered,
            location: vendor.location,
            rating: vendor.rating,
            description: vendor.description,
            operating_hours: vendor.operating_hours,
            business_permit: vendor.business_permit,
            vendor_profile_image: vendor.vendor_profile_image
        };

        const encryptedResponse = encrypt({
            success: true,
            data: vendorProfile
        });

        res.status(200).send(encryptedResponse);
    } catch (error) {
        console.error(error);
        res.status(500).send(
            encrypt({
                success: false,
                message: 'An error occurred while fetching the vendor profile'
            })
        );
    }
};

exports.getVendorReviews = async (req, res) => {
    try {
        const { vendorId } = req.user;

        const vendor = await Vendor.findById(vendorId);
        if (!vendor) {
            return res.status(200).send(encrypt({
                success: false,
                message: 'Vendor not found'
            }));
        }

        const reviews = await Review.aggregate([
            {
                $match: {
                    vendor_id: new mongoose.Types.ObjectId(vendor.vendor_id)
                }
            },
            {
                $lookup: {
                    from: 'users',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $unwind: '$user'
            },
            {
                $project: {
                    review_id: '$_id',
                    rating: 1,
                    comment: 1,
                    review_date: 1,
                    'name': '$user.name',
                    'email': '$user.email'
                }
            },
            {
                $sort: { review_id: -1 }
            }
        ]);

        if (reviews.length > 0) {
            return res.status(200).send(encrypt({
                success: true,
                data: reviews
            }));
        } else {
            return res.status(200).send(encrypt({
                success: false,
                message: 'No reviews found'
            }));
        }
    } catch (error) {
        console.error('Error in getVendorReviews:', error);
        return res.status(200).send(encrypt({
            success: false,
            message: 'An error occurred while fetching vendor reviews'
        }));
    }
};

exports.updateVendorInformation = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { accountId, vendorId } = req.user;

        const {
            location,
            description,
            operating_hours,
            vendor_name,
            vendor_email,
            contact_number
        } = req.body;

        const vendorUpdateFields = {};
        const vendorAccUpdateFields = {};

        if (location) vendorUpdateFields.location = location;
        if (description) vendorUpdateFields.description = description;
        if (operating_hours) vendorUpdateFields.operating_hours = operating_hours;
        if (vendor_name) {
            vendorUpdateFields.vendor_name = vendor_name;
            vendorAccUpdateFields.vendor_name = vendor_name;
        }

        if (vendor_email) vendorAccUpdateFields.vendor_email = vendor_email;
        if (contact_number) vendorAccUpdateFields.contact_number = contact_number;

        if (Object.keys(vendorUpdateFields).length === 0 &&
            Object.keys(vendorAccUpdateFields).length === 0) {
            const error = new Error("No valid fields to update");
            error.status = 400;
            throw error;
        }

        let updatedVendor;
        if (Object.keys(vendorUpdateFields).length > 0) {
            updatedVendor = await Vendor.findOneAndUpdate(
                { _id: vendorId },
                vendorUpdateFields,
                { new: true, session }
            );

            if (!updatedVendor) {
                const error = new Error("Vendor not found");
                error.status = 404;
                throw error;
            }
        }

        let updatedVendorAccount;
        if (Object.keys(vendorAccUpdateFields).length > 0) {
            updatedVendorAccount = await VendorAccount.findOneAndUpdate(
                { _id: accountId },
                vendorAccUpdateFields,
                { new: true, session }
            );

            if (!updatedVendorAccount) {
                const error = new Error("Vendor account not found");
                error.status = 404;
                throw error;
            }
        }

        await session.commitTransaction();

        const responseData = {
            message: "Vendor information updated successfully",
            vendor: {
                ...(updatedVendor?.toObject() || {}),
                ...(updatedVendorAccount ? {
                    vendor_email: updatedVendorAccount.vendor_email,
                    contact_number: updatedVendorAccount.contact_number
                } : {})
            }
        };

        res.status(200).send(encrypt({
            success: true,
            data: responseData
        }));

    } catch (error) {
        await session.abortTransaction();
        console.error('Error in updateVendorInformation:', error);

        const status = error.status || 500;
        const message = error.status ? error.message : "An error occurred while updating vendor information";

        res.status(status).send(encrypt({
            success: false,
            message,
            ...(status === 500 && { error: error.message })
        }));
    } finally {
        session.endSession();
    }
};

exports.updateVendorLogo = async (req, res) => {
    try {
        const { vendorId } = req.user;

        if (!req.file) {
            return res.status(400).send(encrypt({
                success: false,
                message: "No valid image file provided"
            }));
        }

        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
        if (!allowedTypes.includes(req.file.mimetype)) {
            return res.status(400).send(encrypt({
                success: false,
                message: "Invalid image type. Only JPG, PNG, and GIF are allowed."
            }));
        }

        const file = bufferToDataURI(req.file.buffer, req.file.originalname).content;

        const result = await cloudinary.uploader.upload(file, {
            folder: 'vendor_profiles',
            transformation: [
                { width: 500, height: 500, crop: 'fill' },
                { quality: 'auto' }
            ]
        });

        const updatedVendor = await Vendor.findByIdAndUpdate(
            vendorId,
            { vendor_profile_image: result.secure_url },
            { new: true }
        );

        if (!updatedVendor) {
            return res.status(404).send(encrypt({
                success: false,
                message: "Vendor not found"
            }));
        }

        res.status(200).send(encrypt({
            success: true,
            message: "Vendor profile image updated successfully",
            data: {
                image_url: result.secure_url
            }
        }));

    } catch (error) {
        console.error('Error in updateVendorLogo:', error);
        res.status(500).send(encrypt({
            success: false,
            message: "An error occurred while updating vendor profile image",
            error: error.message
        }));
    }
};

exports.updateVendorLogo = async (req, res) => {
    try {
        const { vendorId } = req.user;

        if (!req.file) {
            return res.status(400).send(encrypt({
                success: false,
                message: "No valid image file provided"
            }));
        }

        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
        if (!allowedTypes.includes(req.file.mimetype)) {
            return res.status(400).send(encrypt({
                success: false,
                message: "Invalid image type. Only JPG, PNG, and GIF are allowed."
            }));
        }

        const file = bufferToDataURI(req.file.buffer, req.file.originalname).content;

        const result = await cloudinary.uploader.upload(file, {
            folder: 'vendor_profiles',
            transformation: [
                { width: 500, height: 500, crop: 'fill' },
                { quality: 'auto' }
            ]
        });

        const updatedVendor = await Vendor.findByIdAndUpdate(
            vendorId,
            { vendor_profile_image: result.secure_url },
            { new: true }
        );

        if (!updatedVendor) {
            return res.status(404).send(encrypt({
                success: false,
                message: "Vendor not found"
            }));
        }

        res.status(200).send(encrypt({
            success: true,
            message: "Vendor profile image updated successfully",
            data: {
                image_url: result.secure_url
            }
        }));

    } catch (error) {
        console.error('Error in updateVendorLogo:', error);
        res.status(500).send(encrypt({
            success: false,
            message: "An error occurred while updating vendor profile image",
            error: error.message
        }));
    }
};