const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const Vendor = require('../models/vendorModel');
const VendorAccount = require('../models/vendorAccountModel');
require('dotenv').config();

passport.use(
    new GoogleStrategy(
        {
            clientID: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
            callbackURL: `${process.env.CLIENT_URL}/api/vendors/auth/google/callback`,
        },
        async (accessToken, refreshToken, profile, done) => {
            try {
                const existingAccount = await VendorAccount.findOne({
                    vendor_email: profile.emails[0].value
                });

                if (existingAccount) {
                    if (!existingAccount.googleId) {
                        return done(null, false, {
                            message: 'This email is registered manually. Please sign in with email and password.',
                        });
                    }

                    const vendor = await Vendor.findOne({ vendor_id: existingAccount._id });
                    return done(null, { account: existingAccount, profile: vendor });
                }

                const newVendorAccount = await VendorAccount.create({
                    vendor_name: profile.displayName,
                    vendor_email: profile.emails[0].value,
                    googleId: profile.id,
                    password: null,
                    contact_number: ''
                });

                const newVendor = await Vendor.create({
                    vendor_id: newVendorAccount._id,
                    vendor_name: profile.displayName,
                    email: profile.emails[0].value,
                    location: 'Please update your location',
                    description: 'Please update your profile description',
                    operating_hours: 'Not specified',
                    rating: 0,
                    emailVerified: true,
                    vendor_profile_image: profile.photos?.[0]?.value || ''
                });

                return done(null, { account: newVendorAccount, profile: newVendor });
            } catch (error) {
                return done(error, null);
            }
        }
    )
);

passport.serializeUser((user, done) => {
    done(null, {
        accountId: user.account._id,
        profileId: user.profile._id
    });
});

passport.deserializeUser(async (ids, done) => {
    try {
        const [account, profile] = await Promise.all([
            VendorAccount.findById(ids.accountId),
            Vendor.findById(ids.profileId)
        ]);

        if (!account || !profile) {
            return done(new Error('User not found'), null);
        }

        done(null, { account, profile });
    } catch (error) {
        done(error, null);
    }
});

module.exports = passport;