// config/cloudinaryConfig.js
const cloudinary = require('cloudinary').v2;
const multer = require('multer');

// Validate environment variable
if (!process.env.CLOUDINARY_URL) {
    console.error('Missing CLOUDINARY_URL environment variable');
    throw new Error('Missing CLOUDINARY_URL environment variable');
}

// Configure Cloudinary - it will automatically parse the URL
try {
    cloudinary.config();
    console.log('Cloudinary configured successfully');
} catch (error) {
    console.error('Error configuring Cloudinary:', error);
    throw error;
}

// Configure multer to use memory storage
const storage = multer.memoryStorage();
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit
    },
    fileFilter: (req, file, cb) => {
        // Accept images only
        if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
            return cb(new Error('Only image files are allowed!'), false);
        }
        cb(null, true);
    }
});

// Add a test function to verify Cloudinary configuration
const testCloudinaryConnection = async () => {
    try {
        const testResult = await cloudinary.uploader.upload(
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
            { public_id: "test" }
        );
        console.log('Cloudinary test upload successful');
        await cloudinary.uploader.destroy("test");
        return true;
    } catch (error) {
        console.error('Cloudinary test upload failed:', error);
        return false;
    }
};

module.exports = { 
    upload, 
    cloudinary,
    testCloudinaryConnection 
};