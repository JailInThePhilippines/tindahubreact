const jwt = require("jsonwebtoken");

const authMiddleware = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({ message: "No token provided" });
        }

        const token = authHeader.split(" ")[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        console.log("Decoded Token:", decoded);

        req.user = {
            vendorId: decoded.vendorId,
            accountId: decoded.accountId,
            email: decoded.email
        };

        console.log("Extracted User:", req.user);

        if (!req.user.vendorId) {
            return res.status(403).json({ message: "Unauthorized: Vendor ID missing" });
        }

        next();
    } catch (error) {
        console.error("Auth middleware error:", error);
        return res.status(401).json({ message: "Invalid token" });
    }
};

module.exports = authMiddleware;
