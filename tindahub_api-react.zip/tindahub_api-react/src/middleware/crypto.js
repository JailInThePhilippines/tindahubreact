const CryptoJS = require('crypto-js');

const SECRET_KEY = process.env.ENCRYPTION_KEY;

const encrypt = (data) => {
  try {
    const stringData = typeof data === 'string' ? data : JSON.stringify(data);
    
    const encrypted = CryptoJS.AES.encrypt(stringData, SECRET_KEY).toString();
    
    const base64 = Buffer.from(encrypted).toString('base64');
    
    return base64;
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Encryption failed');
  }
};

const decrypt = (encryptedData) => {
  try {
    const fromBase64 = Buffer.from(encryptedData, 'base64').toString('utf8');
    
    const decrypted = CryptoJS.AES.decrypt(fromBase64, SECRET_KEY);
    
    const originalData = decrypted.toString(CryptoJS.enc.Utf8);
    
    try {
      return JSON.parse(originalData);
    } catch {
      return originalData;
    }
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Decryption failed');
  }
};

module.exports = { encrypt, decrypt };